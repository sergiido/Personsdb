(function() {
	var counter = 10;
	var users = [];
	var questions = [{
			id: 1,
			q: "Which tag inserts an image to HTML document?",
			options: ["image", "img", "picture"],
			tag: "radio"
		},
		{
			id: 2,
			q: "Tag for a unnumeric list",
			options: ["al", "ul", "ui", "li"],
			tag: "radio"
		},
		{
			id: 3,
			q: "Types for input tags",
			options: ["text", "password", "image", "button"],
			tag: "checkbox"
		}
	];
	var correctAnswers = new Map();
	correctAnswers.set(1, ["image"]);
	correctAnswers.set(2, ["ul"]);
	correctAnswers.set(3, ["text", "password", "button"]);

	module.exports = {
		getQuestions: function(cb) {
			cb(questions);
		},
		checkAnswers: function(quizResults) {
			var rightCounter = 0;
 			for (var i = 0; i < quizResults.length; i++) {
 				let answers = correctAnswers.get(quizResults[i].id);
 				if (quizResults[i].options.join() == answers.join()) {
 					rightCounter++;
 				}
 			}
 			return rightCounter*100/quizResults.length;
		}
	};
}());